#!/bin/zsh

# Скрипт для установки Bore напрямую с GitHub
# Автоматически определяет архитектуру и загружает соответствующую версию

echo "🚀 Начинаем установку Bore..."

# Определяем архитектуру системы
arch=$(uname -m)
echo "📊 Обнаружена архитектура: $arch"

# Устанавливаем правильный URL в зависимости от архитектуры
if [[ "$arch" == "arm64" ]]; then
  download_url="https://github.com/ekzhang/bore/releases/download/v0.5.2/bore-v0.5.2-aarch64-apple-darwin.tar.gz"
  echo "🖥️  Архитектура ARM (Apple Silicon) обнаружена"
elif [[ "$arch" == "x86_64" ]]; then
  download_url="https://github.com/ekzhang/bore/releases/download/v0.5.2/bore-v0.5.2-x86_64-apple-darwin.tar.gz"
  echo "🖥️  Архитектура Intel (x86_64) обнаружена"
else
  echo "❌ Ошибка: Неподдерживаемая архитектура: $arch"
  exit 1
fi

# Проверяем, установлен ли уже Bore
if command -v bore &> /dev/null; then
  echo "⚠️  Bore уже установлен в $(which bore), будет заменен"
fi

# Создаем временную директорию для загрузки
temp_dir=$(mktemp -d)
echo "📁 Создана временная директория: $temp_dir"
cd "$temp_dir" || { echo "❌ Ошибка: не удалось перейти во временную директорию"; exit 1; }

# Загружаем архив
echo "📥 Загружаем Bore с $download_url..."
if curl -L -# "$download_url" -o bore.tar.gz; then
  echo "✅ Загрузка завершена успешно"
else
  echo "❌ Ошибка: не удалось загрузить файл"
  cd - > /dev/null
  rm -rf "$temp_dir"
  exit 1
fi

# Распаковываем архив
echo "📦 Распаковываем архив..."
if tar -xzf bore.tar.gz; then
  echo "✅ Распаковка завершена успешно"
else
  echo "❌ Ошибка: не удалось распаковать архив"
  cd - > /dev/null
  rm -rf "$temp_dir"
  exit 1
fi

# Делаем файл исполняемым
echo "🔐 Устанавливаем права на исполнение..."
chmod +x bore

# Определяем директорию для установки
install_dir="/usr/local/bin"

# Проверяем существование директории и права доступа
if [[ ! -d "$install_dir" ]]; then
  echo "📁 Создаем директорию $install_dir..."
  sudo mkdir -p "$install_dir" || { echo "❌ Ошибка: не удалось создать директорию"; exit 1; }
fi

# Перемещаем бинарный файл в директорию для исполняемых файлов
echo "📋 Перемещаем bore в $install_dir..."
if sudo mv bore "$install_dir/"; then
  echo "✅ Файл успешно перемещен"
else
  echo "❌ Ошибка: не удалось переместить файл"
  cd - > /dev/null
  rm -rf "$temp_dir"
  exit 1
fi

# Очищаем временные файлы
cd - > /dev/null
rm -rf "$temp_dir"
echo "🧹 Временные файлы удалены"

# Проверяем установку
if command -v bore &> /dev/null; then
  version=$(bore --version 2>&1 || echo "Версия не определена")
  echo "🎉 Bore успешно установлен в $(which bore)"
  echo "🔍 $version"
  echo "📘 Вы можете запустить 'bore --help' для получения справки"
else
  echo "⚠️ Установка завершена, но команда 'bore' не найдена в PATH."
  echo "Возможно, вам нужно добавить $install_dir в переменную PATH или перезапустить терминал."
fi

echo "✨ Установка завершена!"