document.addEventListener('DOMContentLoaded', () => {
    const socket = io();
    const output = document.getElementById('output');
    const commandInput = document.getElementById('command-input');
    const prompt = document.getElementById('prompt');

    // Переменные состояния
    let currentDirectory = '';
    let commandHistory = [];
    let historyIndex = -1;
    let isRunning = false;

    // Обновление приглашения с текущей директорией
    function updatePrompt() {
        // Показать директорию в приглашении
        const shortenedDir = currentDirectory.replace(/^\/Users\/([^/]+)/, '~');
        prompt.textContent = `${shortenedDir} $ `;
    }

    // Обработка обновлений директории
    socket.on('directory', (dir) => {
        currentDirectory = dir;
        updatePrompt();
    });

    // Обработка выполнения команд
    function executeCommand(command) {
        if (isRunning) return;

        isRunning = true;
        appendToOutput(`${prompt.textContent}${command}\n`, 'command');
        socket.emit('execute', command);

        // Добавление команды в историю, если она не пустая
        if (command.trim() !== '') {
            // Удаление дубликата, если существует
            const index = commandHistory.indexOf(command);
            if (index > -1) {
                commandHistory.splice(index, 1);
            }
            commandHistory.unshift(command);
            historyIndex = -1;

            // Ограничение размера истории
            if (commandHistory.length > 100) {
                commandHistory.pop();
            }
        }
    }

    // Добавление текста в область вывода
    function appendToOutput(text, className = '') {
        const span = document.createElement('span');
        span.className = className;
        span.textContent = text;
        output.appendChild(span);
        output.scrollTop = output.scrollHeight;
    }

    // Очистка терминала
    function clearTerminal() {
        output.innerHTML = '';
    }

    // Обработка событий клавиш
    commandInput.addEventListener('keydown', (event) => {
        // Обработка клавиши Enter
        if (event.key === 'Enter') {
            const command = commandInput.value.trim();
            commandInput.value = '';

            // Обработка специальных команд
            if (command === 'clear') {
                clearTerminal();
                socket.emit('done', 0);
                isRunning = false;
                return;
            }

            executeCommand(command);
        }
        // Обработка стрелки вверх для истории
        else if (event.key === 'ArrowUp') {
            if (historyIndex < commandHistory.length - 1) {
                historyIndex++;
                commandInput.value = commandHistory[historyIndex];
                // Перемещение курсора в конец ввода
                setTimeout(() => {
                    commandInput.selectionStart = commandInput.selectionEnd = commandInput.value.length;
                }, 0);
            }
            event.preventDefault();
        }
        // Обработка стрелки вниз для истории
        else if (event.key === 'ArrowDown') {
            if (historyIndex > 0) {
                historyIndex--;
                commandInput.value = commandHistory[historyIndex];
            } else if (historyIndex === 0) {
                historyIndex = -1;
                commandInput.value = '';
            }
            event.preventDefault();
        }
        // Обработка Ctrl+C для прерывания работающего процесса
        else if (event.key === 'c' && event.ctrlKey) {
            if (isRunning) {
                appendToOutput('\n^C\n');
                socket.emit('terminate');
                event.preventDefault();
            }
        }
    });

    // Обработка вывода команды
    socket.on('output', (data) => {
        appendToOutput(data);
    });

    // Обработка ошибок команды
    socket.on('error', (data) => {
        appendToOutput(data, 'error');
    });

    // Обработка завершения команды
    socket.on('done', (code) => {
        isRunning = false;
        if (code !== 0) {
            appendToOutput(`\nПроцесс завершился с кодом ${code}\n`, 'error');
        }
        // Автоматический фокус на поле ввода после завершения команды
        commandInput.focus();
    });

    // Автоматический фокус на поле ввода при загрузке страницы
    commandInput.focus();

    // Сохранение фокуса на поле ввода при клике в любом месте терминала
    document.getElementById('terminal').addEventListener('click', () => {
        commandInput.focus();
    });

    // Отображение приветственного сообщения
    appendToOutput('Добро пожаловать в WebShell - Веб-терминал для macOS\n', 'success');
    appendToOutput('Введите команды ниже или "clear" для очистки терминала\n\n', 'success');

    // Инициализация приглашения
    updatePrompt();
});